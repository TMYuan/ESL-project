#include "widget.h"
#include <QtGui/QApplication>
#include <QtGui/QPushButton>
#include <QtGui/QFont>
#include <QtGui/QWidget>
#include <QtGui/QLabel>
#include <QtGui/QImage>
#include <QPainter>

#include <QTimer>
#include <iostream>
#include <vector>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/opencv.hpp"
using namespace cv;
using namespace std;


PainterWidget::PainterWidget()
{
    btn_next=new QPushButton(this);
    btn_next->setText(">>");
	btn_next->setFont(QFont("Courier", 18, QFont::Bold));
	btn_next->setGeometry(650,100,110,50);
	QObject::connect(btn_next, SIGNAL(clicked()), this, SLOT(img_next()));

	index=0;
	
	QImage img= QImage("01.jpg");
	vec_img.push_back(img);
	
	/*
		
		
		code here
		
		
	*/
	
	
	
	

	
}
PainterWidget::~PainterWidget()
{
	
}
void PainterWidget::img_next()
{
	/*
		code here
	*/
	update(); //call paintEvent(QPaintEvent*event) function
}
void PainterWidget::img_last()
{
	/*
		code here
	*/
	update(); //call paintEvent(QPaintEvent*event) function
}
void PainterWidget::paintEvent(QPaintEvent*event) {
	
	
	
}
